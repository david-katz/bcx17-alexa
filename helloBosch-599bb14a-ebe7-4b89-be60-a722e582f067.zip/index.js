/* eslint-disable  func-names */
/* eslint quote-props: ["error", "consistent"]*/
/**
 * This sample demonstrates a sample skill built with Amazon Alexa Skills nodejs
 * skill development kit.
 * This sample supports multiple languages (en-US, en-GB, de-GB).
 * The Intent Schema, Custom Slot and Sample Utterances for this skill, as well
 * as testing instructions are located at https://github.com/alexa/skill-sample-nodejs-howto
 **/

'use strict';


exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.APP_ID = APP_ID;
    // To enable string internationalization (i18n) features, set a resources object.
    alexa.resources = languageStrings;
    alexa.registerHandlers(handlers);
    alexa.execute();
};


var Alexa = require('alexa-sdk');
var APP_ID = undefined; // TODO replace with your app ID (OPTIONAL).
var recipes = require('./recipes');
var https = require('https');

const handlers = {
     'PlaybackStarted': function() { 
        this.attributes['enqueuedToken'] = false;
     },
     'PlaybackFinished': function() { 
        console.log("PlaybackFinished");    
     },
         
     'Unhandled': function() {
         console.log('Unhandled',this);
     },
     'PlaybackNearlyFinished' : function () {
         console.log("PlaybackNearlyFinished");
         this.attributes['enqueuedToken']=true;
         
             // Options and headers for the HTTP request   
    var options = {
        host: 'efvp0jra7k.execute-api.eu-central-1.amazonaws.com',
        port: 443,
        path: '/prod/pushupDetected?full=true',
        method: 'GET',
        headers: {
                    'x-api-key':'64yHdLKCT77S0741RawXY4ZJ6tRtZsfz2cRgMABW',
                 }
    };
    
    var self2 = this;

    // Setup the HTTP request
    var req = https.request(options, function (res) {

        res.setEncoding('utf-8');
              
        // Collect response data as it comes back.
        var responseString = '';
        res.on('data', function (data) {
            responseString += data;
        });
        
        // Log the responce received from Twilio.
        // Or could use JSON.parse(responseString) here to get at individual properties.
        res.on('end', function () {
            var obj = JSON.parse(responseString);
            obj = obj.Item;
            console.log('Drill Response: ' + responseString,obj);
            
            var fn = "kniebeugen.mp3";
            if(obj.numCalls == 1) {
                switch(obj.pushupsDone) {
                case 1:
                    fn = "eins.mp3";
                    break;
                case 2:
                    fn = "zwei.mp3";
                    break;
                case 3:
                    fn = "drei.mp3";
                    break;
                }
            }
            else {
                if(obj.pushupsDone >= 3)
                    fn = "stille.mp3";
                    
                if(obj.pushupsDone >= 3 && obj.numCalls == 3) {
                    fn = "bonus.mp3";
                }
                else if(obj.pushupsDone >= 3 && obj.numCalls >= 4) {
                    return;
                }
                else if(obj.numCalls == 10) {
                    fn = "faul.mp3";
                }
                else if(obj.numCalls >= 11) {
                    return;
                }
            }

            console.log("PlaybackNearlyFinished",fn,obj,self2);
            self2.response.audioPlayerPlay("ENQUEUE", "https://symonics.com/bcw/"+fn, "1234567abcd", "1234567abcd", 0);
            self2.emit(':responseReady');

        });
        

        });
    req.end();

     },
    
      'LaunchRequest': function () {
            console.log("LaunchRequest");
        this.attributes['speechOutput'] = this.t("WELCOME_MESSAGE", this.t("SKILL_NAME"));
        // If the user either does not reply to the welcome message or says something that is not
        // understood, they will be prompted again with this text.
        this.attributes['repromptSpeech'] = this.t("WELCOME_REPROMPT");
        this.emit(':ask', this.attributes['speechOutput'], this.attributes['repromptSpeech'])
    },
    'RecipeIntent': function () {

        var itemSlot = this.event.request.intent.slots.Item;
        var itemName;
        if (itemSlot && itemSlot.value) {
            itemName = itemSlot.value.toLowerCase();
        }

        var cardTitle = this.t("DISPLAY_CARD_TITLE", this.t("SKILL_NAME"), itemName);
        var recipes = this.t("RECIPES");
        var recipe = recipes[itemName];

        if(itemName == "kniebeugen") {

    // Options and headers for the HTTP request   
    var options = {
        host: 'efvp0jra7k.execute-api.eu-central-1.amazonaws.com',
        port: 443,
        path: '/prod/startExercising',
        method: 'POST',
        headers: {
                    'x-api-key':'64yHdLKCT77S0741RawXY4ZJ6tRtZsfz2cRgMABW',
                 }
    };
    
    var self=this;
    // Setup the HTTP request
    var req = https.request(options, function (res) {

        res.setEncoding('utf-8');
              
        // Collect response data as it comes back.
        var responseString = '';
        res.on('data', function (data) {
            responseString += data;
        });
        
        // Log the responce received from Twilio.
        // Or could use JSON.parse(responseString) here to get at individual properties.
        res.on('end', function () {
            console.log('Start Response: ' + responseString);
            self.response.audioPlayerPlay("REPLACE_ALL", "https://symonics.com/bcw/intro.mp3", "1234567abcd", null, 0);
            self.emit(':responseReady');        });

    });

    req.end();
    

        
//            this.attributes.speechOutput = this.t('KNIEBEUGEN_BESCHREIBUNG');
//            this.attributes.repromptSpeech = this.t('RECIPE_REPEAT_MESSAGE');
//            this.emit(':tell', this.attributes.speechOutput);
            
        } else {
            let speechOutput = this.t('RECIPE_NOT_FOUND_MESSAGE');
            const repromptSpeech = this.t('RECIPE_NOT_FOUND_REPROMPT');
            if (itemName) {
                speechOutput += this.t('RECIPE_NOT_FOUND_WITH_ITEM_NAME', itemName);
            } else {
                speechOutput += this.t('RECIPE_NOT_FOUND_WITHOUT_ITEM_NAME');
            }
            speechOutput += repromptSpeech;

            this.attributes.speechOutput = speechOutput;
            this.attributes.repromptSpeech = repromptSpeech;
            this.emit(':ask', speechOutput, repromptSpeech);
        } 
        /*
        if (recipe) {
            this.attributes['speechOutput'] = recipe;
            this.attributes['repromptSpeech'] = this.t("RECIPE_REPEAT_MESSAGE");
            this.emit(':tellWithCard', recipe, this.attributes['repromptSpeech'], cardTitle, recipe);
        } else {
            var speechOutput = this.t("RECIPE_NOT_FOUND_MESSAGE");
            var repromptSpeech = this.t("RECIPE_NOT_FOUND_REPROMPT");
            if (itemName) {
                speechOutput += this.t("RECIPE_NOT_FOUND_WITH_ITEM_NAME", itemName);
            } else {
                speechOutput += this.t("RECIPE_NOT_FOUND_WITHOUT_ITEM_NAME");
            }
            speechOutput += repromptSpeech;

            this.attributes['speechOutput'] = speechOutput;
            this.attributes['repromptSpeech'] = repromptSpeech;

            this.emit(':ask', speechOutput, repromptSpeech);
        }
        */
    },
/*
    'RecipeIntent': function () {

            
        
        const itemSlot = this.event.request.intent.slots.Item;
        let itemName;
        if (itemSlot && itemSlot.value) {
            itemName = itemSlot.value.toLowerCase();
        }
        
        const cardTitle = this.t('DISPLAY_CARD_TITLE', this.t('SKILL_NAME'), itemName);
        const myRecipes = this.t('RECIPES');
        
        if(itemName == "kniebeugen") {
        
            this.attributes.speechOutput = this.t('KNIEBEUGEN_BESCHREIBUNG');
            this.attributes.repromptSpeech = this.t('RECIPE_REPEAT_MESSAGE');
            this.emit(':tell', this.attributes.speechOutput, this.attributes.repromptSpeech);
        } else {
            let speechOutput = this.t('RECIPE_NOT_FOUND_MESSAGE');
            const repromptSpeech = this.t('RECIPE_NOT_FOUND_REPROMPT');
            if (itemName) {
                speechOutput += this.t('RECIPE_NOT_FOUND_WITH_ITEM_NAME', itemName);
            } else {
                speechOutput += this.t('RECIPE_NOT_FOUND_WITHOUT_ITEM_NAME');
            }
            speechOutput += repromptSpeech;

            this.attributes.speechOutput = speechOutput;
            this.attributes.repromptSpeech = repromptSpeech;
            this.emit(':ask', speechOutput, repromptSpeech);
        }     
       
    },
    */
    'AMAZON.HelpIntent': function () {
        this.attributes.speechOutput = this.t('HELP_MESSAGE');
        this.attributes.repromptSpeech = this.t('HELP_REPROMT');
        this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
    },
    'AMAZON.RepeatIntent': function () {
        this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
    },
    'AMAZON.StopIntent': function () {
        this.emit('SessionEndedRequest');
    },
    'AMAZON.CancelIntent': function () {
        this.emit('SessionEndedRequest');
    },
    'SessionEndedRequest': function () {
        this.emit(':tell', this.t('STOP_MESSAGE'));
    },
};

const languageStrings = {
    'en-GB': {
        translation: {
            SKILL_NAME: 'British Minecraft Helper',
            WELCOME_MESSAGE: "Welcome to %s. You can ask a question like, what\'s the recipe for a chest? ... Now, what can I help you with.",
            WELCOME_REPROMT: 'For instructions on what you can say, please say help me.',
            DISPLAY_CARD_TITLE: '%s  - Recipe for %s.',
            HELP_MESSAGE: "You can ask questions such as, what\'s the recipe, or, you can say exit...Now, what can I help you with?",
            HELP_REPROMT: "You can say things like, what\'s the recipe, or you can say exit...Now, what can I help you with?",
            STOP_MESSAGE: 'Goodbye!',
            RECIPE_REPEAT_MESSAGE: 'Try saying repeat.',
            RECIPE_NOT_FOUND_MESSAGE: "I\'m sorry, I currently do not know ",
            RECIPE_NOT_FOUND_WITH_ITEM_NAME: 'the recipe for %s. ',
            RECIPE_NOT_FOUND_WITHOUT_ITEM_NAME: 'that recipe. ',
            RECIPE_NOT_FOUND_REPROMPT: 'What else can I help with?',
        },
    },
    'en-US': {
        translation: {
            SKILL_NAME: 'American Minecraft Helper',
            WELCOME_MESSAGE: "Welcome to %s. You can ask a question like, what\'s the recipe for a chest? ... Now, what can I help you with.",
            WELCOME_REPROMT: 'For instructions on what you can say, please say help me.',
            DISPLAY_CARD_TITLE: '%s  - Recipe for %s.',
            HELP_MESSAGE: "You can ask questions such as, what\'s the recipe, or, you can say exit...Now, what can I help you with?",
            HELP_REPROMT: "You can say things like, what\'s the recipe, or you can say exit...Now, what can I help you with?",
            STOP_MESSAGE: 'Goodbye!',
            RECIPE_REPEAT_MESSAGE: 'Try saying repeat.',
            RECIPE_NOT_FOUND_MESSAGE: "I\'m sorry, I currently do not know ",
            RECIPE_NOT_FOUND_WITH_ITEM_NAME: 'the recipe for %s. ',
            RECIPE_NOT_FOUND_WITHOUT_ITEM_NAME: 'that recipe. ',
            RECIPE_NOT_FOUND_REPROMPT: 'What else can I help with?',
        },
    },
    'de-DE': {
        translation: {
            SKILL_NAME: 'Bosch Drill Sergeant',
            WELCOME_MESSAGE: 'Willkommen bei %s. Welche Übung möchtest Du machen?',
            WELCOME_REPROMT: 'Wenn du wissen möchtest, was sagen kannst, sag einfach „Hilf mir“.',
            DISPLAY_CARD_TITLE: '%s - Rezept für %s.',
            HELP_MESSAGE: 'Ich, dein Bosch Drill Sergeant, sorge dafür, dass Du genügend Sport treibst. Ich zähle deine Kniebeugen, Liegestützen, und Klimzüge.',
            HELP_REPROMT: 'Du kannst beispielsweise Sachen sagen wie „Liegenbeugen zählen“ oder du kannst „Beenden“ sagen ... Fange endlich an, Faulpelz.',
            STOP_MESSAGE: 'Bis zum nächsten Training.',
            RECIPE_REPEAT_MESSAGE: 'Sage einfach „Wiederholen“.',
            RECIPE_NOT_FOUND_MESSAGE: 'Ich kenne ',
            RECIPE_NOT_FOUND_WITH_ITEM_NAME: 'die %s Übung nicht. ',
            RECIPE_NOT_FOUND_WITHOUT_ITEM_NAME: 'diese Übung nicht.',
            RECIPE_NOT_FOUND_REPROMPT: 'Fange endlich an Sport zu treiben!',
            KNIEBEUGEN_BESCHREIBUNG: 'Stelle dich aufrecht hin. Beine zusammen. Dann, hebe beide Arme in die Waagerechte. Jetzt gehe langsam in die Knie bis dein Hintern unten ist und dann langsam wieder nach oben. Mache diese Übung dreimal.'
        },
    },
};
